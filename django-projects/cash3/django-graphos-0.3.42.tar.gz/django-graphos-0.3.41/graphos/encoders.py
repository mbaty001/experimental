from django.core.serializers.json import DjangoJSONEncoder


class GraphosEncoder(DjangoJSONEncoder):
    pass

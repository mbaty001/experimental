""" Graphos Exceptions """


class GraphosException(Exception):
    pass
